fsoot=1;
lamda=0.55;
r=0.02;
R=0.02/(fsoot)^(1/3);
ka=1;
%ka=2*pi*r/lamda;

a=R*load('ns512.txt');
fid = fopen('ns512100.pos','w+');
fclose(fid);
%a=R*a;
%a(1:N,1)=ka;
b=a;
a(:,1)=r;

a(:,5)=1.76;
a(:,6)=0.63;

b(:,5)=1.55;
b(:,6)=0;

%for i=1:N
    %R=(R-r)*rand;
   % phi=pi*rand;
    %theta=2*pi*rand;
   % b(i,2)=a(i,2)+R*sin(phi)*cos(theta);
    %b(i,3)=a(i,3)+R*sin(phi)*sin(theta);
   % b(i,4)=a(i,4)+R*cos(phi);
%end
N=size(a,1);
for i=1:N

     fid = fopen('ns512100.pos','a');
    fprintf(fid,'%12.7f',a(i,:));
 
%     fprintf(fid,'\r\n',''); 
%      fprintf(fid,'%12.7f',b(i,:));

    fprintf(fid,'\r\n',''); 
    fclose(fid);
end
