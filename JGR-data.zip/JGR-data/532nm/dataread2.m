
clear;
clc;
lujing='E:\DDSCATbusuan\532nm\MSTM\';
dir1=dir(lujing);
for i=1:length(dir1)
    if length(dir1(i).name)>2
        mydir=strcat(lujing,dir1(i).name,'\');
    else
        continue;
    end
    

    temp1=dir([mydir,'*.dat']);
    fid = fopen('data.txt','w+');
    fclose(fid);
    num_temp1=length(temp1);
 
    for i1=1:num_temp1

        filename=[mydir,temp1(i1).name];
        fidin=fopen(filename); % ��test2.txt�ļ� 
        d=filename(length(filename)-5:length(filename)-4)
        while ~feof(fidin) % �ж��Ƿ�Ϊ�ļ�ĩβ 
            tline=fgetl(fidin); % ���ļ�����
            a=strtrim(tline);
            if strcmpi(a,'number of spheres, volume size parameter:')
                b=fgetl(fidin);
            elseif strcmpi(a,'total ext, abs, scat efficiencies, w.r.t. xv, and asym. parm')
                    c=fgetl(fidin);
                    %c=strtrim(c);
                    fid = fopen('data.txt','a');
                    fprintf(fid,'%c',c);
                    fprintf(fid,'\t','');
                    fprintf(fid,'%c',b);
                    fprintf(fid,'  ','');
                    fprintf(fid,'%c',d);
                    fprintf(fid,'\n','');
                    fclose(fid);
                    %m=importdata('data.txt');
                     break;
                     
            end
        
     end
    fclose(fidin);

    end

 data=importdata('data.txt'); 
  xlswrite(dir1(i).name, data)
end
  %data=int(data) 
%eval_r([temp1(i1).name(1:end-4),'=temp;'])
%dlmread��fopen�Ȳ����Ͳ�����д�ˣ��뵥���ļ�һ����
%end