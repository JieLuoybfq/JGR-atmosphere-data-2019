clear;
clc;
lujing='E:\DDSCATbusuan\532nm\MSTM\';
dir1=dir(lujing);
for i=1:length(dir1)
    if length(dir1(i).name)>2
        mydir=strcat(lujing,dir1(i).name,'\');
    else
        continue;
    end
    

    temp1=dir([mydir,'*.dat']);
    fid = fopen('depo.txt','w+');
    fclose(fid);
    num_temp1=length(temp1);
 
    for i1=1:num_temp1

        filename=[mydir,temp1(i1).name];
        fidin=fopen(filename); % ��test2.txt�ļ� 
        d=filename(length(filename)-5:length(filename)-4);
        while ~feof(fidin) % �ж��Ƿ�Ϊ�ļ�ĩβ 
            tline=fgetl(fidin); % ���ļ�����
            a=strtrim(tline);
            if strcmpi(a,'number of spheres, volume size parameter:')
                ns=fgetl(fidin);
            end
            b=' ';
            if length(a)>6
                b=a(1:6);
            end
            if strcmpi(b,'180.00')
                    Scatting_at_pi=str2num(a(9:strlength(a)));
                    F11_pi=Scatting_at_pi(1);
                    F22_pi=Scatting_at_pi(5);
                    liner_dipo=(1-F22_pi)./(1+F22_pi);
            %elseif strcmpi(a,'total ext, abs, scat efficiencies, w.r.t. xv, and asym. parm')
                   % c=fgetl(fidin);
                    %c=strtrim(c);
                    fid = fopen('depo.txt','a');
                    fprintf(fid,'%c',liner_dipo);
                    fprintf(fid,'  ','');
                    ns
                    fprintf(fid,'%c',ns);
                   % fprintf(fid,'\t','');
                   % fprintf(fid,'%c',b);
                    fprintf(fid,'  ','');
                    fprintf(fid,'%c',d);
                    fprintf(fid,'\n','');
                    fclose(fid);
                    %m=importdata('data.txt');
                     %break;
                     
            end
        
     end
    fclose(fidin);

    end

 data=importdata('depo.txt'); 
 filename=strcat(dir1(i).name,'_depo')
  xlswrite(filename, data)
end
  %data=int(data) 
%eval_r([temp1(i1).name(1:end-4),'=temp;'])
%dlmread��fopen�Ȳ����Ͳ�����д�ˣ��뵥���ļ�һ����
%end